from django.urls import path
from . import views

urlpatterns = [
    path('festivals/', views.FestivalsAPI.as_view()),
    # path('posts/', views.PostsAPI.as_view()),
    # path('posts/create', views.PostAPI.as_view()),
]
